package com.example.tripapp.detail;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.tripapp.MyApplication;
import com.example.tripapp.databinding.FragmentDetailNewsBinding;
import com.example.tripapp.network.MyAdapter;
import com.example.tripapp.network.Page;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class DetailNewsFragment extends Fragment {
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        FragmentDetailNewsBinding binding = FragmentDetailNewsBinding.inflate(inflater, container, false);

        MyApplication application = (MyApplication) getActivity().getApplicationContext();
        Call<Page> call = application.networkService.getList(
                "swiss",
                application.API_KEY,
                1,
                10
        );

        call.enqueue(new Callback<Page>() {
            @Override
            public void onResponse(Call<Page> call, Response<Page> response) {
                if(response.isSuccessful()){
                    binding.newsRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
                    binding.newsRecyclerView.setAdapter(new MyAdapter(application, response.body().articles));
                }
            }

            @Override
            public void onFailure(Call<Page> call, Throwable t) {

            }
        });
        return binding.getRoot();
    }
}
