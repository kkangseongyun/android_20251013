package com.example.tripapp.network;

import java.util.ArrayList;

public class Page {
    public ArrayList<News> articles;
}
